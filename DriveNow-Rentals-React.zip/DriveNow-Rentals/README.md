# DriveNow Rentals (React)

## Requirements
- Node.js (LTS)
- npm

## Run the project
1. Extract the `DriveNow-Rentals` folder.
2. Open this folder in VS Code.
3. Open Terminal in VS Code.
4. Run:

```bash
npm install
npm run dev
```

5. Open the local URL shown in the terminal (usually http://localhost:5173).

## Project files
- `src/App.jsx` – React components and application logic
- `src/App.css` – Website styling
- `src/main.jsx` – React entry point
- `index.html` – HTML page
- `package.json` – Dependencies and scripts

Car photos are requested from Wikipedia's public summary API. An internet connection is needed for those images; the app shows a placeholder if an image is unavailable.

**Payment note:** This is a front-end student demo. The payment step is simulated and does not collect card details or process real payments. A real payment system requires a secure payment provider and a backend.
